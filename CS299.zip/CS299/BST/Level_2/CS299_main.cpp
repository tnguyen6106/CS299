#include "CS299_bst.h"
//Please place your name here:
//
//

int main()
{
    node * root = NULL;
    build(root);
    display_all(root);

    /*  PLACE YOUR FUNCTION CALL HERE */

    cout << "Largest data in the BST is: " << display_largest_node(root) << endl;
    display_all(root);
    destroy(root);

    return 0;
}
