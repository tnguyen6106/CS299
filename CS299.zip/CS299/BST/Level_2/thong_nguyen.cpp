#include "CS299_bst.h"

int display_largest_node(node * root)
{
    if(!root)
        return 0;
    if(!root -> right)
    {
        //cout << "Largest data is: " << root -> data << endl;
        return root -> data;
    }
    return display_largest_node(root -> right);
}

int count_root_data(node * root)
{
    if(!root)
        return 0;
    
}
