#include "CS299_bst.h"

int main()
{
    node * root = NULL;
    node * new_root = NULL;
    build(root);
    display_all(root);

    /*  PLACE YOUR FUNCTION CALL HERE */
    //int number = root -> data;
//    cout << "Number of nodes that have data larger than root: " << count_greater_root_data(root -> right, number) << endl;
//    cout << "Number of nodes in whole tree: " << count_whole_tree(root) << endl;
//    cout << "Sum of every leaf's data: " << count_sum_no_leaves(root) << endl; 
//    display_all(root);
//    cout << "Height of the tree is: " << determine_height(root) << endl;
    //cout << "Root's inorder successor data is: " << find_inorder(root -> right) << endl;
  //  cout << "Number of nodes deleted: " << delete_all(root) << endl;
    //destroy(root);
    cout << "Number of nodes copied: " << copy_tree(root, new_root) << endl;
    cout << "=====================================================" << endl;
    display_all(new_root);
    return 0;
}
