#include "CS299_bst.h"

/*int count_greater_root_data(node * root, int data)
{
    if(!root)
        return 0;
    int count = 0;
    if(root -> data > data)
        ++count; 
        //return count_greater_root_data(root -> right, data) + 1;
    //return count_greater_root_data(root -> left, data) + 0;
    int left = count_greater_root_data(root -> left, data);
    int right = count_greater_root_data(root -> right, data);
    return left + right + count;
}*/

int count_greater_root_data(node * root, int data)
{
    if(!root)
        return 0;
    int count = 0;
    //if(root -> data > data)
     //   ++count; 
    if(root -> data > data)
        count += 1;
    int left = count_greater_root_data(root -> right, data);
    int right = count_greater_root_data(root -> left, data);
    return left + right + count;
    //int left = count_greater_root_data(root -> left, data);
    //int right = count_greater_root_data(root -> right, data);
    //return left + right + count;
}

int count_whole_tree(node * root)
{
    if(!root)
        return 0;
    int left = count_whole_tree(root -> left);
    int right = count_whole_tree(root -> right);
    return left + right + 1;
}

int count_sum_no_leaves(node * root)
{
    
    int sum = 0;
    if(!root)
        return 0;
    if(root -> left == NULL && root -> right == NULL)
        sum += root -> data;
    int left = count_sum_no_leaves(root -> left);
    int right = count_sum_no_leaves(root -> right);
    return left + right + sum;

}

/*int determine_height()
{
    return determine_height(root);
}*/

int determine_height(node * root)
{
    if(!root)
        return 0;
    int left = determine_height(root -> left);
    int right = determine_height(root -> right);
    if(left > right)
        return left + 1;
    else
        return right + 1;
}

int find_inorder(node * root)
{
    if(!root)
        return 0;
    if(!root -> left)
        return root -> data;
    return find_inorder(root -> left);
}


int delete_all(node *& root)
{
    if(!root)
        return 0;
    int remove = delete_all(root -> left) + delete_all(root -> right) + 1;
    delete root;
    root = NULL;
    return remove;
}
//Make a complete copy of a BST, creating a new BST
int insert_node(node * source, node *& destination)
{
    if(!destination)
    {
        destination = new node;
        destination -> data = source -> data;
        destination -> left = NULL;
        destination -> right = NULL;
        return 1;
    }
    else
    {
        if(source -> data < destination -> data)
            return insert_node(source, destination -> left);
        else
            return insert_node(source, destination -> right);
    }
}

int copy_tree(node * source, node *& destination)
{
    if(!source)
        return 0;
    insert_node(source, destination);
    int total_nodes = copy_tree(source -> left, destination) + copy_tree(source -> right, destination) + 1;
    return total_nodes;
}
