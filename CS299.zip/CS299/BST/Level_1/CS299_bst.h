#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;

struct node
{
    int data;
    node * left;
    node * right;
};

void build(node * & root);   //supplied
void display_all(node *  root);  //supplied
void destroy(node * & root); //supplied
/* ************** PLACE YOUR PROTOTYPE HERE ***************** */
int count_greater_root_data(node * root, int data); 
int count_whole_tree(node * root);

int count_sum_no_leaves(node * root);
int determine_height(node * root);  

int find_inorder(node * root);
int delete_all(node *& root);

int copy_tree(node * source, node *& destination);
int insert_node(node * source, node *& destination);

