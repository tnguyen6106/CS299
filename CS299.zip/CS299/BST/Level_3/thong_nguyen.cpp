#include "CS299_bst.h"

int table::count_larger()
{
    return count_larger(root);
}

int table::count_larger(node * root)
{
    int smallest_data = find_smallest(root -> left);
    cout << "Smallest data is: " << smallest_data << endl;
    return count_larger(root, smallest_data); 
}

int table::count_larger(node * root, int & smallest)
{
    if(!root)
        return 0;
    if(root -> data > smallest)
    {
        return count_larger(root -> left, smallest) + count_larger(root -> right, smallest) + 1;
    }
    return count_larger(root -> left, smallest) + count_larger(root -> right, smallest) + 0;

}

int table::find_smallest(node * root)
{
    if(root -> left == NULL)
        return root -> data;
    return find_smallest(root -> left) + 0;  
}
//===============================================//
int table::remove_leaf()
{
    if(!root)
        return 0;
    return remove_leaf(root);
}

int table::remove_leaf(node *& root)
{
    if(!root)
        return 0;
    if(!root -> left && !root -> right)
    {
        if(root -> data != this -> root -> data)
        {
            delete root;
            root = NULL;
        }
        return 1;
    }
    return remove_leaf(root -> left) + remove_leaf(root -> right) + 0;
}
//===========================================//
int table::copy_multiples(table & new_copy)
{
    if(!root)
        return 0;
   /* if(!new_copy.root)
    {
        new_copy.root = new node;
        new_copy.root -> data = root -> data;
        new_copy.root -> left = NULL;
        new_copy.root -> right = NULL:
    }*/
    //copy_multiples(new_copy.root -> left, root -> left);
    //copy_multiples(new_copy.root -> right, root -> right);
    return copy_multiples(new_copy.root, root);
}

int table::copy_multiples(node *& new_root, node * source_root)
{
    if(!source_root)
        return 0;
    if(source_root -> data % 3 == 0)
    {
        insert_node(source_root, new_root);
        return copy_multiples(new_root, source_root -> left) + copy_multiples(new_root, source_root -> right) + 1;
    }
    return copy_multiples(new_root, source_root -> left) + copy_multiples(new_root, source_root -> right) + 0;


}

int table::insert_node(node * source, node *& dest)
{
    if(!dest)
    {
        dest = new node;
        dest -> data = source -> data;
        dest -> left = NULL;
        dest -> right = NULL;
        return 0;
    }
    if(source -> data < dest -> data)
    { 
            /*dest -> left = new node;
            dest -> left -> data = source -> data;*/
        return insert_node(source, dest -> left);
    }
    else
    {
            /*dest -> right = new node;
            dest -> right -> data = source -> data;*/
        return insert_node(source, dest -> right); 
    } 
}

/*int table::copy_binary_tree(table & new_copy)
{
    if(!root)
        return 0;
}*/
