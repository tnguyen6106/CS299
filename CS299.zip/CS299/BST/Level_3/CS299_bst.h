#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;

struct node
{
    int data;   //some questions use char * data;
    node * left;
    node * right;
};

class table
{
    public:
    	//These functions are supplied already
    	table();			//supplied
    	~table();			//supplied
        void build(); 		//supplied
        void display(); 	//supplied


/* ************** PLACE YOUR PROTOTYPE HERE ***************** */
        int count_larger();
        int remove_leaf();
        int copy_multiples(table & new_copy);
        int copy_binary_tree(table & new_copy);

 	private:
 		node * root;
        int count_larger(node * root);
        int count_larger(node * root, int & smallest);
        int find_smallest(node * root);
        //=========================//
        int remove_leaf(node *& root);
        int copy_multiples(node *& new_root, node * source_root);
        int insert_node(node * source, node *& dest);

        int copy_binary_tree(node *& new_root, node * source_root);
};
  

