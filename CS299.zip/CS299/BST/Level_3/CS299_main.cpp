#include "CS299_bst.h"
//Please place your name here:
//
//

int main()
{
    table object;
    object.build(); 	//builds a BST
    object.display();	//displays a BST
    table object2;

    /*  PLACE YOUR FUNCTION CALL HERE */
    //cout << "Nodes that have data larger than smallest data is: " << object.count_larger() << endl;
    //cout << "Number of nodes removed: " << object.remove_leaf() << endl;
    cout << "Number of nodes copied: " << object.copy_multiples(object2) << endl;
    
    object2.display();
    object.display();	//displays again after!
   
    return 0;
}
