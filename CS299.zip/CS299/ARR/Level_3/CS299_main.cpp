#include "CS299_arr.h"
//Please place your name here:
//
//


int main()
{
    table object; 
    object.build(); //creates an array of LLL
    object.display(); //displays the array

    //PLEASE PUT YOUR CODE HERE to call the functions
    //cout << "Number of data displays: " << object.display_reverse();
    table newObj;
    std::cout << object.copy_arr(newObj);

    newObj.display();

    
    
    return 0;
}
