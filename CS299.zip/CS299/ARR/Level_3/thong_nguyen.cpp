#include "CS299_arr.h"

/*int list::addLongest()
{

}

int list::find_longest_list(node ** head)
{
   //if(size == 0)
    //   return 0;
    int longest_index = -1;
    int shortest_index = -1;
    int longest = 0;
    int shortest = 0;
}

int list::find_longest_list_wrapper(node * head, int & total_nodes)
{


}
int list::count_nodes_lll(node * head);
{
    if(!head)
        return 0;
    return count_nodes_lll(head -> next) + 1;

}*/

int table::display_reverse()
{
    return display_reverse(head, size - 1);
}

int table::display_reverse(node ** head, int index)
{
    if(index == -1)
        return 0;
    std::cout << index << " " << std::endl;
    int count = display_reverse(*(head + (index)));
    std::cout << std::endl;
    return display_reverse(head, index - 1) + count;
}

int table::display_reverse(node * head)
{
    if(!head)
        return 0;
    int count = display_reverse(head -> next) + 1;
    cout << head -> data << " ";
    return count;
}

//Average all of the data in an array of linear linked list. Return the average

float table::average_all()
{
    float total_nodes = 0.0;
    float sum = 0.0;
    average_all(head, size-1, total_nodes, sum);
    cout << "Total nodes: " << total_nodes << endl;
    cout << "Total data: " << sum << endl;
    return sum/total_nodes;
}

float table::count(node * head, float & sum)
{
    if(!head)
        return 0.0;
    sum += head -> data;
    return count(head -> next, sum) + 1.0;
}

float table::average_all(node ** head, int index, float & total_nodes, float & total_data)
{
    if(index == -1)
        return 0.0;
    total_nodes += count(*(head + (index)), total_data);
    return average_all(head, index - 1, total_nodes, total_data) + 0.0;
}

//Make complete copy of an array of linear linked list
int table::copy_arr(table & new_table)
{
    if(!head)
        return 0;
    new_table.head = new node * [size];
    new_table.size = size;
    for ( int i = 0 ; i <size ; i++)
            new_table.head[i] = NULL;
    return copy_arr(head, new_table.head, 0);


}

int table::copy_arr(node ** src, node **& dst, int size)
{
   
    if (size == this->size)
        return 0;
    insert_helper ( *(src + size), *(dst+size));
    return copy_arr ( src, dst, size +1) + 1;
    

    
    
}





void table::insert_helper ( node * src, node *& dst)
{
    if (!src) return;
    add_helper ( src, dst);
    insert_helper ( src->next, dst);

}







void table::add_helper ( node * src, node *& dst)
{

    if (dst == NULL)
    {
        dst = new node;
        dst ->data = src->data;
        cout << dst -> data << " "; 
        dst->next = NULL;
        return;
    }
    else 
    {

        node * newNode = new node;
        newNode->data = src->data;
        cout << newNode -> data << " ";
        newNode->next = dst;
        dst = newNode;
        return;


    }


}










