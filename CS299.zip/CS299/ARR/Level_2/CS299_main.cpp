#include "CS299_arr.h"
//Please place your name here:
//
//
using namespace std;

int main()
{
    node * head[SIZE] = {0,0,0,0,0};
    build(head);
    display_all(head);

    //PLEASE PUT YOUR CODE HERE to call the functions
    //display_except(head, SIZE);
    //remove_last_lll(head, SIZE);
    cout << "Total nodes added: " << add_end(head, SIZE); 

    display_all(head);
    destroy(head);
    
    return 0;
}
