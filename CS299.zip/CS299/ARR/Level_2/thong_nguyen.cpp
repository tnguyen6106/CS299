#include "CS299_arr.h"
using namespace std;
int display_except(node * head)
{
    if(!head)
            return 0;
    if (head->next == NULL) return 0;
    cout << head -> data << " ";
    return display_except(head -> next);
}

int display_except(node * head[], int size)
{
    if(size == 0)
    {
        return 0;
    }
    display_except(head[size - 1]); //argument can be change to (*(head + (size - 1)))
    cout << endl;
    return display_except(head, size - 1);

}

int remove_last_lll(node * rear[], int size)
{
    if(!rear)
        return 0;
    return remove_last_lll(*(rear + (size - 1)));
    
        
}

int remove_last_lll(node *& rear)
{
    if(!rear)
        return 0;
    if(!rear -> next)
    {
        delete rear;
        rear = NULL;
        return 1;
    }
    node * temp = rear;
    rear = temp -> next;
    temp -> next = NULL;
    delete temp;
    return remove_last_lll(rear) + 1;

}

int add_end(node * head[], int size) 
{
    if(size == 0)
        return 0;
    node * ptr = *(head + (size -1));
    int first_data = ptr-> data;
    int total = add_end_helper(ptr, first_data);
    return add_end(head, size - 1) + total;

}
int add_end_helper(node *& head, int & value)
{
    if(!head)
    {
        head = new node;
        head -> data = value;
        head ->next = NULL;
        return 1;
    }
    return add_end_helper(head -> next, value) + 0; 
}
