#include "CS299_clist.h"
//Add a node before each node that has "even" data in a CLL,
//returning the number of nodes added
int list::add_before()
{
    if(!rear)
        return 0;
    //node * tempHead = rear;
    return add_before(rear);
}

int list::add_before(node *& rear)
{
    if(rear -> next == this -> rear)
    {
        if(rear -> next -> data %2  == 0)
        {   
            node * temp = new node;
            temp -> next = rear -> next;
            rear -> next = temp;
            temp -> data = 99;
            return 1;
        }
        else
            return 0;
    }
    
    if(rear -> next -> data % 2 == 0)
    {
        node * temp = new node;
        temp -> next = rear -> next;
        temp -> data = 99;
        rear -> next = temp;
        return add_before(rear -> next -> next) + 1;
    }
    return add_before(rear -> next) + 0;
}


//Remove every node that has the same data
//as rear's data. Do not remove the rear's node. Return if
//anything was removed (true) or not (false)

bool list::remove_same()
{
    if(!rear)
        return false;
    return remove_same(rear);

}

bool list::remove_same(node *& rear)
{
    if(rear -> next == this -> rear)
    {
        return false;
    }
    
    if(rear -> next -> data == this -> rear -> data)
    {
        node * temp = rear -> next;
        rear -> next = temp -> next;
        temp -> next = NULL;
        delete temp;
        remove_same(rear);
        return true;
    }
    else
    {
        remove_same(rear -> next);
        return false;
    }
 
}

//Copy constructor
list::list(const list & object)
{
    if(object.rear)
    {
        node * temp = object.rear; 
        copy_new(object.rear, temp, rear);
    }
}

int list::copy_new(node * source, node * keep_source, node *& destination)
{
    
    if(source -> next == keep_source)
    {
        destination = new node;
        destination -> data = source -> data;
        destination -> next = this -> rear;
        return 0;
    }
    if(!destination)
    {
        destination = new node;
        destination -> data = source -> data;
        destination -> next = destination;
        return copy_new(source -> next, keep_source, destination -> next) + 0;
    }
    else
    {
        destination = new node;
        destination -> data = source -> data;
        destination -> next = this -> rear;
        return copy_new(source -> next, keep_source, destination -> next) + 0;
    }
}

//Switch the first and last nodes in the CLL (not the data - but reattach the nodes correctly)
int list::switch_first_last()
{
    if(!rear)
        return 0;
    node * temp = rear;
    //node * temp2 = rear -> next;
    switch_first_last(rear, temp);
    temp -> next = rear -> next;
    rear -> next = temp;
    //temp -> next = temp2 -> next;
    //temp2 -> next = temp;
    return 1;
}

int list::switch_first_last(node *& rear, node * keep_rear)
{
    if(rear -> next == this -> rear)
    {
        rear -> next = keep_rear -> next;
        this -> rear = keep_rear -> next;
        return 0;
    }
    return switch_first_last(rear -> next, keep_rear) + 0;

}

//Remove the node that rear pointed to
int list::remove_rear()
{
    if(!rear)
        return 0;
    node * temp = rear -> next;
    return remove_rear(rear, temp) + 0;

}

int list::remove_rear(node *& rear, node * keep_rear)
{
    if(rear -> next == this -> rear)
    { 
        rear -> next = this -> rear -> next;
        node * temp = this -> rear;
        this -> rear = rear;
        delete temp;
        return 1;
    }
    return remove_rear(rear -> next, keep_rear);


}







