#include "CS299_clist.h"
//Please place your name here
//
//

int main()
{
    list object;
    object.build();	//builds a circular LL
    object.display();	//displays the list

    //PLEASE PUT YOUR CODE HERE to call the functions
    //cout << "Total added nodes are: " << object.add_before() << endl << endl;
    //object.remove_same();
    /*list new_object(object);
    cout <<  endl << endl <<"Here is the list of new object: ";
    new_object.display();*/
    //object.switch_first_last();
    object.remove_rear();
    object.display(); //resulting list after your function call!
    
    return 0;
}
