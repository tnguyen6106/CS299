//clist.h
#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;


struct node
{
    int data;	//some questions are a char * data;
    node * next;
};

class list
{
   public:
   		//These functions are already written
   		list();			//supplied
   		~list();		//supplied
        list(const list & object);
   		void build();	//supplied
   		void display();	//supplied

	/* *****************YOUR TURN! ********************* */
	//Write your function prototype here:
        int add_before();
        bool remove_same();
        int copy_new(node * source, node * keep_source, node *& destination);
        int switch_first_last();
        int remove_rear();
	private:
        int remove_rear(node *& rear, node * keep_rear);
        int add_before(node *& rear);
        bool remove_same(node *& rear);
        int switch_first_last(node *& rear, node * keep_rear);
		node * rear;
};
