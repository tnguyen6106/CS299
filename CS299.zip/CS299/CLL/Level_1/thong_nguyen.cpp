#include "CS299_clist.h"

int display_except(node * rear)
{
        if(!rear)
            return 0;
        node * temp = rear -> next;
        int sum = 0; 
        while(temp -> next != rear)
        {
            sum += temp -> data; 
            cout << temp -> data << " ";
            temp = temp -> next;
        }
        cout << endl;
        return sum;
}

bool remove_last(node *& rear)
{
        if(!rear)
            return false;

        node * temp = rear -> next;
        while(temp -> next != rear)
        {
            temp = temp -> next;
        }
        temp -> next = rear -> next;
        delete rear;
        rear = temp;
        return true;
}

int copy_all(node *& new_rear, node * source_rear)
{
    if(!source_rear)
    {
        new_rear = NULL;
        return 0;
    }

    node * temp = source_rear -> next;
    if(!new_rear)
    {
            node * new_temp = new node; 
            new_temp -> data = temp -> data;

            new_rear = new_temp;
            new_rear -> next = new_rear;
    }
    node * new_head = new_rear; 

    while(temp != source_rear)   
    {
            new_rear = new_rear -> next;
            new_rear -> data = temp -> data;
            new_rear -> next = new_head;
            temp = temp -> next;
    }
    new_rear = new_rear -> next;
}
