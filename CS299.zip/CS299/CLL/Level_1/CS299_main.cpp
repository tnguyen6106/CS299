#include "CS299_clist.h"
//Your name:
//
//

using namespace std;

int main()
{
    node * rear = NULL;
    node * new_rear = NULL;
    build(rear);
    display_all(rear);

    //PLEASE PUT YOUR CODE HERE to call the functions
    
    //cout << "Sum of all nodes except last is: " << display_except(rear);
    //remove_last(rear);
    copy_all(new_rear, rear);
    display_all(new_rear);

    display_all(rear); //resulting list after your function call!
    destroy(rear);
    
    return 0;
}
