//clist.h
#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;

struct node
{
    int data;
    node * next;
};

/* These functions are already written and can be called to test out your code */
void build(node * & rear);  //supplied
void display_all(node * rear);  //supplied
void destroy(node * & rear); //supplied

/* *****************YOUR TURN! ******************************** */
//Write your function prototype here:
int removal_entire(node *& rear);
int count_all_wrapper(node * rear);
int count_all(node * rear, node * head);
int add_new_node_wrapper(node *& rear, int data);
int add_new_node(node *& rear, node * head, int data, int & count);
bool duplicate_wrapper(node *& new_copy, node * original);
bool duplicate(node *& new_copy, node * new_head, node * original, node * head);


