#include "CS299_clist.h"

//Remove the entire CLL
int removal_entire(node *& rear)
{ 
    if(rear -> next == rear)
    {
        delete rear; 
        rear = NULL;
        return 1;
    }
    node * temp = rear -> next;
    rear -> next = temp -> next;
    temp -> next = NULL;
    delete temp;
    int sum = removal_entire(rear) + 1;
    return sum;
}

//Count all even nodes in the CLL, return the count
int count_all_wrapper(node * rear)
{
    if(rear == NULL)
        return 0;
    node * temp = rear -> next;
    return count_all(rear, temp);
}

int count_all(node * rear, node * head)
{
    if(head == rear)
    {
        if(head -> data % 2 == 0)
            return 1;
        else
            return 0;
    }
    if(head -> data % 2 == 0)
    {
        return count_all(rear, head -> next) + 1;
    }
    else
        return count_all(rear, head -> next) + 0;
}

//Add a new node to the end of a CLL but only if the data
//doesnt already exist in the CLL

int add_new_node_wrapper(node *& rear, int data)
{
    if(rear == NULL)
        return 0;
    node * temp = rear -> next;
    int exist = 0;
    add_new_node(rear, temp, data, exist);
    if(exist == 0)
    {
        node * temp = new node;
        temp -> next = rear -> next;
        rear -> next = temp;
        temp -> data = data;
        rear = temp;
    }
    return 1;
}

int add_new_node(node *& rear, node * head, int data, int & exist)
{
    if(head == rear)
        return 0;
    if(head -> data == data)
    {
        ++exist;
        return add_new_node(rear, head -> next, data, exist);
    }
    else
    {
        return add_new_node(rear, head -> next, data, exist);
    }

}

//Make a complete and duplicate copy of a circular linked list; 
//return if the new list has any data in it (true) or not (false)
bool duplicate_wrapper(node *& new_copy, node * original)
{
    if(!original)
    {
        new_copy = NULL;
        return false;
    }
    return duplicate (new_copy, NULL, original, original->next); 
}

bool duplicate(node *& new_copy, node * new_head, node * original, node * head)
{

    // case 1: 1 node
    if ( original->next == original)
    {
        new_copy = original;
        new_copy->next = new_copy;
        return true;
    }
    //  case 2 
    if(head == original)
    {
            node * newNode = new node;
       newNode->data = head->data;
       newNode->next = new_head;
       new_copy->next = newNode;
       new_copy = newNode;
    
        return true;
    }
    //case 3 
    if ( new_copy == NULL)
    {
        node * newNode = new node;
       newNode->data = head->data;
        new_copy = newNode;
        new_copy->next = new_copy;
        new_head = new_copy;
    }
    else {

       node * newNode = new node;
       newNode->data = head->data;
       newNode->next = new_head;
       new_copy->next = newNode;
       new_copy = newNode;
    
    }
    
    
    return duplicate(new_copy, new_head, original, head->next);

}
