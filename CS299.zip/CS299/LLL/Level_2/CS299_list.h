//list.h
#include <iostream>
#include <cctype>
#include <cstdlib>
using namespace std;


//The data structure is a linear linked list of integers
struct node
{
    int data;
    node * next;
};

//These functions are already written and used by main
void build(node * & head);      //supplied
void display_all(node * head);  //supplied
void destroy(node * &head);     //supplied


/* *****************YOUR TURN! ******************************** */
/* PLACE YOUR PROTOTYPE HERE */


//Average
//wrapper
float average(node* head);
//helper
float average(node* head, int& count);

//Count Largest
//wrapper
int countLargest(node* head);
//helper
int countLargest(node* head, int& largest);
int removeAll2s(node*& head);
int addToOdd(node* head, int toAdd);
