#include "CS299_list.h"

//Place your name here in comments:
//Doug Whitley
//CS299
//Spring 17
int main()
{
    //The following code builds the linear linked list
    node * head = NULL;
    build(head);
    display_all(head);

    //PLEASE PUT YOUR CODE HERE to call the functions
    cout << "Average: " << average(head) << endl;
    cout << "Num Largest: " << countLargest(head) << endl;
    cout << "Num 2s removed: " << removeAll2s(head) << endl;
    cout << "Num Odds: " << addToOdd(head, 11) << endl;

    display_all(head);
    destroy(head);    

    return 0;
}


//Average
//wrapper
float average(node* head)
{
    //setup var
    int count = 0;
    //inline calculate average
    return average(head,count)/count;
}
//helper
float average(node* head, int& count)
{
    //base case
    if(!head)
        return 0;

    //No precall or post call work so go right to return statement

    //return the sum of the data and increment the count
    return head->data + average(head->next, ++count);
}


//Count Largest
//wrapper
int countLargest(node* head)
{
    //setup the largest value
    int largest = -1;
    //return the count
    return countLargest(head,largest);
}
//helper
int countLargest(node* head, int& largest)
{
    //base case
    if(!head)
        return 0;
    // precall work
    // update largest
    if(head->data > largest)
        largest = head->data;
    //recursive call
    int ret = countLargest(head->next, largest);
    //post call work
    //see if current node matches largest and update ret value if needed
    if(head->data == largest)
        ++ret;
    //return
    return ret;
}


//Remove all 2s
//function
int removeAll2s(node*& head)
{
    int ret = 0;
    //base case
    if(!head)
        return 0;
    //no precall work
    //recursive call
    ret = removeAll2s(head->next);
    //post call work
    //remove head if it's a 2
    if(head->data == 2)
    {
        node* temp = head;
        head = head->next;
        delete temp;
        ++ret;
    }
    //return
    return ret;
}


//add num to odd nodes
//wrapper
int addToOdd(node* head, int toAdd)
{
    int ret = 0;
    //Base Case
    if(!head)
        return 0;
    //Precall Work
    //see if the node is odd and update it
    if((head->data)%2)
    {
        head->data += toAdd;
        ++ret;
    }
    //recursive call, and return pushed together.
    return ret + addToOdd(head->next, toAdd);
}
