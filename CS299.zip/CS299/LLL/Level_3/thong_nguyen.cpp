#include "CS299_list.h"

//Remove the last two if the sum is larger than the data of the first node
bool list::remove_last_two()
{
    if(!head)
        return false;
    if(!head -> next)
    {
        delete head;
        return true;
    }
    else
    {
        //int first_node_data = head -> data; 
        /*node * temp = head;
        head = head -> next;
        delete temp;*/
        remove_last_two(head);//, first_node_data);
    }


}

bool list::remove_last_two(node *& head)
{
    if(!head)
        return false;
    if(head -> next -> next == tail)
    {
        if(head -> next -> data + head -> next -> next -> data > this -> head -> data)
        {
            delete tail;
            delete head -> next;
            head -> next = NULL;
            tail = head;
            return true;
        }
    }
    remove_last_two(head -> next);//, first_data);
}

//Calculate the average of every data item in a LLL and return the average
float list::average()
{
    if(!head)
        return 0.0;
    else
    {
        int sum_of_nodes = 0;
        int total_nodes = average(head, sum_of_nodes);
        return sum_of_nodes/(float)total_nodes;
        
    }
}

int list::average(node * head, int & sum)
{
    if(!head)
        return 0;
    sum += head -> data;
    return average(head -> next, sum) + 1;
}

//Add a node (with data value of 99) after each node that has a data value larger than the last node's data

int list::add_99()
{
    if(!head)
        return 0;
    return add_99(head);

}

int list::add_99(node *& head)
{
    if(!head)
        return 0;
    if(!head -> next)
    {
        return 0;
    }
    if(head -> data > tail -> data)
    {
        node * temp = new node;
        temp -> data  = 99;
        temp -> next = head -> next;
        head -> next = temp;
        return add_99(head -> next -> next) + 1;
    }
    return add_99(head -> next);
}

//Copy all even data that exists in a LLL and build a new LLL, return the number of items in the new LLL

int list::copy_even(list & new_list)
{
    if(!head)
    {
        new_list.head = NULL;
        return 0;
    }
    return copy_even(head, new_list.head, new_list.tail); 
}

int list::copy_even(node * source, node *& destination, node *& new_tail)
{
    if(!source)
    {
        destination = NULL;
        return 0;
    }
    if(source -> data % 2 == 0)
    {
       //if(destination == NULL)
       // {
            destination = new node;
            destination -> data = source -> data;
            destination -> next = NULL;
            new_tail = destination;
            return copy_even(source -> next, destination -> next, new_tail) + 1;
        //}
    }
    return copy_even(source -> next, destination, new_tail) + 0;
}














