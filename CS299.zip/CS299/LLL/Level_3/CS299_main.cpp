#include "CS299_list.h"
//Place your name here

int main()
{
    list object;
    list new_object;
    object.build();    //builds a LLL
    object.display();  //displays the LLL

    //PLEASE PUT YOUR CODE HERE to call the functions

  //bool to_catch = object.remove_last_two();  
   
    /* float catch_average = object.average();
    cout << catch_average << endl; */

   /*int times_99_added = object.add_99();
   cout << times_99_added << endl;*/

    int totalNodesOfNewList = object.copy_even(new_object); 
    cout << "Total number copied: " << totalNodesOfNewList << endl;
    object.display();  //displays the LLL again!
    cout << "HERE IS THE NEW COPIED LIST: \n";
    new_object.display(); 
    
    return 0;
}
