#include "CS299_dlist.h"

//Sum the data of the last two nodes in the DLL,
//returning the sum
//Below is wrapper function
int sum_last_two(node * head)
{
    if(!head)
        return 0;
    int count = 0;
    int sum = 0;
    return sum_last_two_recurse(head, count, sum);
}

//Recursive function for returning sum of last two nodes
int sum_last_two_recurse(node * head, int & count, int & sum)
{
    if(!head)
        return 0;
    sum_last_two_recurse(head -> next, count, sum);
    if(count < 2)
    {
        sum += head -> data;
        count += 1;
    }
    return sum;
    

}

//Display contents of the DLL in reverse,
//return the last node's data item (the first to be displayed
//and display that again from main
int display_reverse(node * rear)
{
    if(!rear)
        return 0;
    if(!rear -> next) //Check if at last node then cout last node's data
                      //then return the last node data;
    {
        cout << rear -> data << " ";
        return display_reverse(rear -> next) + rear -> data;
    }
    else
    {
        int last_node = display_reverse(rear -> next) + 0;
        cout << rear -> data << " ";
        return last_node;
    }
    
}

//Add a new node to the end of a DLL but only if the data doesn't already
//exist in the DLL
int add_not_exist(node * rear)
{
    if(!rear)
    {
        return 0;
    }
    int data = 5;
    return add_not_exist(rear, data);

}
//Recursive function for the function above
int add_not_exist(node *& rear, int to_add)
{
    if(!rear -> next && rear -> data != to_add)
    {
        node * temp = new node;
        temp -> next = NULL;
        temp -> data = to_add;
        temp -> previous = rear;
        rear -> next = temp;
        return 0;
    }
    else if(rear -> data == to_add)
    {
        return 0;
    }
    else
    {
        return add_not_exist(rear -> next, to_add) + 0;
    }


}

//Make a complete and duplicate copy of a doubly linked list 
//return if the new list has any data in it (true) or not (false)
bool duplicate(node *& new_copy, node * original)
{
    if(!original)
        return false;
    if(!new_copy)
    {
        new_copy = new node;
        new_copy -> next = NULL;
        new_copy -> data = original -> data;
        duplicate(new_copy -> next, original -> next);     
    }
    
    return true;
    
}












