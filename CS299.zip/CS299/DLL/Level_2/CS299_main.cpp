#include "CS299_dlist.h"
//Please place your name here
//
//
using namespace std;

int main()
{
    node * head = NULL;
    node * new_head = NULL;
    build(head);
    display_all(head);

    //PLEASE PUT YOUR CODE HERE to call the functions
    //cout << "Total sum of last two node: " << sum_last_two(head) << endl;
    //cout << endl << "Last data of the list is: " << display_reverse(head) << endl;
    //add_not_exist(head); 
    
    duplicate(new_head, head);
    display_all(new_head);
    destroy(head);    
    return 0;
}
