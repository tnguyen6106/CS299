//doubly linked list
//Notice that there is a head and a tail pointer!!!
#include <iostream>
#include <cstring>
#include <cctype>
#include <cstdlib>
using namespace std;


struct node
{
    int data;		//some questions use a char * data;
    node * previous;
    node * next;
};

class list
{
    public:
        //These functions are already written
        list();         //supplied
        ~list();        //supplied
        void build();   //supplied
        void display(); //supplied
                

     /* *****************YOUR TURN! ******************************** */
     /* place your prototype here */
        int copy_not_before(list & source); 
        int display_last2_reverse();
        int remove_frequent();

     private:
        int copy_not_before(node *& source, node *& destination);
        int display_last2_reverse(node * head);

        int remove_frequent(node *& head, node *& tail);
        int remove_frequent(node *& head, node *& tail, int to_remove);
        int find_frequent(node * head, int & numb);
        int compare_data(node * head, int & frequent, int & hold_data);
         node * head;   //notice there is both a head
         node * tail;   //and a tail, common for DLL
};
