#include "CS299_dlist.h"
//Please place your name here:
//
//
using namespace std;


int main()
{
    list object;
    object.build();
    object.display();

    //PLEASE PUT YOUR CODE HERE to call the functions
    /*list new_object;
    new_object.copy_not_before(object);
    cout << "Here is the list of new object: ";
    new_object.display();*/

    object.remove_frequent();

    object.display();
    
    return 0;
}
