#include "CS299_dlist.h"

//Copy every node into a new DLL but not when the node before it has the same data
int list::copy_not_before(list & source)
{
    if(!source.head)
        return 0;
    return copy_not_before(source.head, head);
}

int list::copy_not_before(node *& source, node *& destination)
{
    if(!source)
        return 0;
    if(source -> next == NULL)
    {
        node * temp = new node;
        temp -> data = source -> data;
        temp -> previous = NULL;
        temp -> next = destination;
        destination -> previous = temp;
        destination = temp;
        return 1;
    }
    if(!destination)
    {
        if(source -> data != source -> next -> data) 
        {
            destination = new node;
            destination -> previous = NULL;
            destination -> next = NULL;
            destination -> data = source -> data;
            return copy_not_before(source -> next, destination);
        }
        else
            return copy_not_before(source -> next -> next, destination);
    }
    else
    {
        if(source -> data != source -> next -> data) 
        {
            node * temp = new node;
            temp -> data = source -> data;
            temp -> previous = NULL;
            temp -> next = destination;
            destination -> previous = temp;
            destination = temp;
            return copy_not_before(source -> next, destination);
        }
        else
            return copy_not_before(source -> next -> next, destination);
    }

}

//Display the last two items in the list, in reverse order
//Return the sum of the last two daa items
/*int list::dipslay_last2_reverse()
{
    if(!head)
        return 0;
    if(!head -> next)
        return head -> data;
    return display_last2_reverse(head);

}*/

//Remove the data that appears the most frequent in the DLL
int list::remove_frequent()
{
    return remove_frequent(head, tail);
}

int list::find_frequent(node * head, int & numb)
{
    if(!head)
        return 0;
    if(head -> data == numb)
        return find_frequent(head -> next, numb) + 1;
    else
        return find_frequent(head -> next, numb) + 0;
}

int list::compare_data(node * head, int & frequent, int & hold_data)
{
    if(!head)
        return 0;
    int hold_frequent = find_frequent(head, head -> data);
    if(hold_frequent > frequent)
    {
        frequent = hold_frequent;
        hold_data = head -> data;
    }
    return compare_data(head -> next, frequent, hold_data);

}

int list::remove_frequent(node *& head, node *& tail)
{
    int occurances = 0;
    int most_frequent_data = 0;
    compare_data(head, occurances, most_frequent_data);
    cout << "Data appears most often: " << most_frequent_data << endl;
    cout << "Number of times appears: " << occurances << endl;
    return remove_frequent(head, tail, most_frequent_data);
}

int list::remove_frequent(node *& head, node *& tail, int to_remove)
{
    if(!head)
        return 0;
    if(!head -> next && head -> data != to_remove)
    {
        return 0;
    }
    if(head -> data == to_remove)
    {
        node * temp = head;
        head = head -> next;
        head -> previous = NULL;
        temp -> next = NULL;
        delete temp;
        return remove_frequent(head, tail, to_remove);
    }
    if(head -> next -> data == to_remove)
    {
        if(head -> next -> next == NULL)
        {
            node * temp = head -> next;
            head -> next = NULL;
            temp -> previous = NULL;
            tail = head;
            delete temp;
            return 0;
        }
        else
        {
            node * temp = head -> next;
            head -> next = temp -> next;
            temp -> next -> previous = temp -> previous;
            temp -> previous = NULL;
            temp -> next = NULL;
            delete temp;
            return remove_frequent(head, tail, to_remove);
        }
    }
    else
        return remove_frequent(head -> next, tail, to_remove);

}






