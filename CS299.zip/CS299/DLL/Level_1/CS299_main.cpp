#include "CS299_dlist.h"
//Please place your name here
//
//
using namespace std;

int main()
{
    node * head = NULL;
    build(head);
    display_all(head);

    //PLEASE PUT YOUR CODE HERE to call the functions
    //cout << "Number of items displyed : " << remove_larger(head) << endl; 
    //cout << "Number of items removed: " << remove_every_other(head) << endl;
    cout << "Number of 2 duplicated: " << duplicate_2(head) << endl;

    display_all(head);
    destroy(head);    
    return 0;
}
