#include "CS299_dlist.h"

int remove_larger(node *& head)
{
    if(!head)
        return 0;
    if(!head -> next)
    {
        return 1;
    }
    node * current = head;
    int count = 0;
    while(current != NULL)// -> next != NULL)
    {
        if(current -> data > head -> data)
        {
            //current -> previous -> next = current -> next;
            //current -> next -> previous = current -> previous;
            if(current -> next == NULL)
            {
                current -> previous -> next = NULL;
            }
            else
            {
                current -> previous -> next = current -> next;
                current -> next -> previous = current -> previous;
            }
            delete current;
        }
        
        current = current -> next;
        ++ count;
    }
    current = NULL;
    //head = current;
    return count;
}


int remove_every_other(node *& head)
{
    if(!head)
        return 0;
    if(!head -> next)
        return 1;
    node * current = head;
    int count = 0;
    while(current -> next != NULL)
    { 
        if(current -> next -> next == NULL)
        {
            delete current -> next;
            current -> next = NULL;
        }
        else
        {
            node * temp = current -> next; 
            current -> next -> next -> previous = current;
            current -> next = current -> next -> next;
            delete temp;
            current = current -> next;
        }
        ++ count;
        //current = current -> next;
    }
    current = NULL;
    return count;
}

int duplicate_2(node *& head)
{
    if(!head)
        return 0;
    if(!head -> next)
        return 1;
    node * current = head;
    int count = 0;
    while(current) 
    {
        if(current -> data == 2 && current -> next == NULL)
        {
            node * temp = new node;
            temp -> data = 2;
            temp -> next = NULL;
            current -> next = temp;
            temp -> previous = current;
            ++count;
            current = current -> next -> next;
        }
        else if(current -> data == 2)
        {
            node * temp = new node;
            temp -> next = current -> next;
            temp -> previous = current;
            current -> next -> previous = temp;
            current -> next = temp;
            temp -> data = 2;
            ++count;
            current = current -> next -> next;
        }
        else
            current = current -> next;// -> next; 
    }
    return count; 
}


